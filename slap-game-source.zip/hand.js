/** The hand is cosmetic: a strike begins at contact and never delays game logic. */
export const HAND_ASSET = './assets/hand/slapping-hand.png';

const clamp01 = value => Number.isFinite(value) ? Math.max(0, Math.min(1, value)) : 0;
const finite = (value, fallback = 0) => Number.isFinite(value) ? value : fallback;
const easeOut = value => 1 - (1 - value) ** 3;
const normalMotion = options => !options.reduceMotion && !options.reducedMotion;
const normalize = ({ x, y, direction, power } = {}) => ({
  x: finite(x), y: finite(y), direction: direction < 0 ? -1 : 1, power: clamp01(power),
});

export class HandAnimator {
  constructor() {
    this.clear();
  }

  /** A captured pointer or keyboard charge keeps this pose alive until endFollow. */
  follow(point = {}, nowMs = 0) {
    this.following = { ...normalize(point), at: finite(nowMs) };
    this.striking = null;
    return this;
  }

  /** Releasing pointer capture after strike must not erase the strike animation. */
  endFollow() {
    this.following = null;
    return this;
  }

  strike(point = {}, nowMs = 0, options = {}) {
    this.following = null;
    this.striking = { ...normalize(point), at: finite(nowMs), reducedMotion: !normalMotion(options) };
    return this;
  }

  clear() {
    this.following = null;
    this.striking = null;
    return this;
  }

  /** Coordinates are logical canvas pixels; direction +1 travels left to right. */
  pose(nowMs = 0, options = {}) {
    const source = this.following || this.striking;
    if (!source) return null;
    const { x, y, direction, power } = source;
    const base = {
      x, y, direction, power, angle: direction * 0.55,
      scale: 0.94 + power * 0.12, scaleX: 1, scaleY: 1,
      alpha: 1, contact: false, trail: 0,
    };
    if (this.following) return { ...base, alpha: 0.86 };

    const age = finite(nowMs, source.at) - source.at;
    if (age < 0) return null;
    if (source.reducedMotion || !normalMotion(options)) {
      if (age >= 160) return null;
      return { ...base, contact: true, alpha: 1 - clamp01((age - 100) / 60) };
    }
    if (age >= 400) return null;

    const follow = Math.min(1, age / 60);
    const withdraw = easeOut(clamp01((age - 60) / 340));
    const contact = age <= 60;
    return {
      ...base,
      // Start exactly at the hit point; follow through, then return to the incoming edge.
      x: x + direction * ((12 + power * 15) * easeOut(follow) - (100 + power * 90) * withdraw),
      y: y - (4 + power * 6) * Math.sin(follow * Math.PI / 2) + (105 + power * 55) * withdraw,
      angle: direction * (0.55 + 0.17 * follow - 0.37 * withdraw),
      scale: base.scale * (1 - withdraw * 0.1),
      scaleX: 1 + power * 0.09 * (1 - follow),
      scaleY: 1 - power * 0.05 * (1 - follow),
      alpha: 1 - clamp01((age - 210) / 190),
      contact,
      trail: contact ? power * (1 - age / 110) : 0,
    };
  }
}

/**
 * Draw an upright transparent palm. The configurable pivot is its palm centre,
 * not the image centre, so the visible contact point stays attached to the hit.
 */
export function drawSlappingHand(ctx, { image, pose, width = 186, pivot = { x: 0.5, y: 0.56 }, extendArm = true } = {}) {
  if (!pose || !Number.isFinite(pose.x) || !Number.isFinite(pose.y)) return;
  const alpha = clamp01(pose.alpha);
  if (alpha === 0) return;
  const drawWidth = Math.max(1, finite(width, 186));
  const imageWidth = finite(image?.naturalWidth, 0) || finite(image?.width, 0);
  const imageHeight = finite(image?.naturalHeight, 0) || finite(image?.height, 0);
  const hasImage = imageWidth > 0 && imageHeight > 0 && image?.complete !== false;
  const drawHeight = hasImage ? drawWidth * imageHeight / imageWidth : drawWidth * 1.42;
  const pivotX = Number.isFinite(pivot?.x) ? clamp01(pivot.x) : 0.5;
  const pivotY = Number.isFinite(pivot?.y) ? clamp01(pivot.y) : 0.56;
  ctx.save();
  ctx.globalAlpha *= alpha;
  ctx.translate(pose.x, pose.y);
  ctx.rotate(finite(pose.angle));
  const scale = Math.max(0.01, finite(pose.scale, 1));
  ctx.scale((pose.direction < 0 ? -1 : 1) * scale * Math.max(0.01, finite(pose.scaleX, 1)),
    scale * Math.max(0.01, finite(pose.scaleY, 1)));

  if (pose.trail > 0) {
    ctx.save();
    ctx.globalAlpha *= clamp01(pose.trail) * 0.55;
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#fff5d1';
    ctx.lineWidth = 4;
    for (let i = 0; i < 3; i += 1) {
      const y = -26 + i * 34;
      ctx.beginPath();
      ctx.moveTo(-drawWidth * 0.63, y + 25);
      ctx.lineTo(-drawWidth * (0.91 + i * 0.09), y + 48);
      ctx.stroke();
    }
    ctx.restore();
  }

  if (hasImage) {
    if (extendArm) drawForearm(ctx, drawWidth, drawHeight * (1 - pivotY) - 2);
    ctx.drawImage(image, -drawWidth * pivotX, -drawHeight * pivotY, drawWidth, drawHeight);
  } else {
    drawFallbackHand(ctx, drawWidth);
  }
  ctx.restore();
}

/** Continue the painted wrist out of frame, underneath the PNG's soft join. */
function drawForearm(ctx, width, top) {
  const left = -width * 0.17, right = width * 0.29;
  const farLeft = left - width * 0.04, farRight = right + width * 0.04;
  const bottom = top + 600;
  const skin = ctx.createLinearGradient(left, top, right, top);
  // Match the shading at the generated sprite's wrist edge.
  skin.addColorStop(0, '#864927');
  skin.addColorStop(0.2, '#c27547');
  skin.addColorStop(0.45, '#cf8354');
  skin.addColorStop(0.62, '#ca7d4d');
  skin.addColorStop(0.82, '#9e5630');
  skin.addColorStop(1, '#793f22');
  ctx.fillStyle = skin;
  ctx.beginPath();
  ctx.moveTo(left, top);
  ctx.lineTo(right, top);
  ctx.lineTo(farRight, bottom);
  ctx.lineTo(farLeft, bottom);
  ctx.closePath();
  ctx.fill();
  // Ink only the long edges: a line across the join would expose the bitmap seam.
  ctx.strokeStyle = '#382b28';
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.moveTo(left, top);
  ctx.lineTo(farLeft, bottom);
  ctx.moveTo(right, top);
  ctx.lineTo(farRight, bottom);
  ctx.stroke();
}

/** A small vector palm keeps play legible if the optional PNG cannot be loaded. */
function drawFallbackHand(ctx, width) {
  const k = width / 186;
  ctx.save();
  ctx.scale(k, k);
  ctx.fillStyle = '#d59a70';
  ctx.strokeStyle = '#382b28';
  ctx.lineWidth = 4;
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(-37, 114);
  ctx.lineTo(-38, 56);
  ctx.bezierCurveTo(-55, 44, -66, 23, -76, 5);
  ctx.bezierCurveTo(-87, -13, -76, -24, -65, -13);
  ctx.lineTo(-43, 9);
  ctx.lineTo(-48, -67);
  ctx.bezierCurveTo(-50, -88, -30, -90, -29, -70);
  ctx.lineTo(-24, -27);
  ctx.lineTo(-23, -103);
  ctx.bezierCurveTo(-23, -123, -2, -122, -3, -102);
  ctx.lineTo(-1, -30);
  ctx.lineTo(2, -111);
  ctx.bezierCurveTo(3, -132, 24, -131, 24, -110);
  ctx.lineTo(22, -29);
  ctx.lineTo(29, -92);
  ctx.bezierCurveTo(33, -112, 52, -108, 49, -89);
  ctx.lineTo(44, -15);
  ctx.bezierCurveTo(48, 22, 43, 41, 31, 58);
  ctx.lineTo(35, 114);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.strokeStyle = '#a6694b';
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.moveTo(-27, 22);
  ctx.quadraticCurveTo(-8, 34, 19, 25);
  ctx.moveTo(-23, 3);
  ctx.quadraticCurveTo(-3, -7, 24, 0);
  ctx.moveTo(-29, 88);
  ctx.lineTo(26, 88);
  ctx.stroke();
  ctx.restore();
}
