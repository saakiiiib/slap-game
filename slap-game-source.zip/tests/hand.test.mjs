import test from 'node:test';
import assert from 'node:assert/strict';
import { HAND_ASSET, HandAnimator, drawSlappingHand } from '../hand.js';

const hit = { x: 247, y: 260, direction: 1, power: 0.8 };

test('the hand is absent until input starts, and the asset uses a project-relative URL', () => {
  assert.equal(new HandAnimator().pose(0), null);
  assert.equal(HAND_ASSET, './assets/hand/slapping-hand.png');
});

test('pointer following persists for long holds and updates without a hit', () => {
  const hand = new HandAnimator().follow(hit, 0);
  assert.equal(hand.pose(90_000).x, hit.x);
  assert.equal(hand.pose(90_000).contact, false);
  hand.follow({ ...hit, x: 360, direction: -1, power: 1 }, 90_001);
  const pose = hand.pose(90_002);
  assert.equal(pose.x, 360);
  assert.equal(pose.direction, -1);
  assert.ok(pose.angle < 0);
  hand.endFollow();
  assert.equal(hand.pose(90_003), null);
});

test('accepted hits contact the exact cheek immediately in both directions', () => {
  for (const direction of [-1, 1]) {
    const hand = new HandAnimator().strike({ ...hit, direction }, 700);
    const pose = hand.pose(700);
    assert.equal(pose.x, hit.x);
    assert.equal(pose.y, hit.y);
    assert.equal(pose.contact, true);
    assert.equal(pose.alpha, 1);
    assert.equal(pose.direction, direction);
    assert.equal(Math.sign(pose.angle), direction);
  }
});

test('follow-through follows the swipe, then withdraws toward the incoming edge and down', () => {
  for (const direction of [-1, 1]) {
    const hand = new HandAnimator().strike({ ...hit, direction }, 100);
    const follow = hand.pose(160);
    const withdrawal = hand.pose(400);
    assert.ok((follow.x - hit.x) * direction > 0);
    assert.ok((withdrawal.x - hit.x) * direction < 0);
    assert.ok(withdrawal.y > hit.y);
    assert.ok(withdrawal.alpha > 0 && withdrawal.alpha < 1);
    assert.equal(hand.pose(500), null);
    assert.equal(hand.pose(80), null);
  }
});

test('harder hits make a larger hand and stronger follow-through without moving initial contact', () => {
  const gentle = new HandAnimator().strike({ ...hit, power: 0 }, 0);
  const hard = new HandAnimator().strike({ ...hit, power: 1 }, 0);
  assert.equal(gentle.pose(0).x, hard.pose(0).x);
  assert.ok(hard.pose(0).scale > gentle.pose(0).scale);
  assert.ok(hard.pose(60).x > gentle.pose(60).x);
  assert.ok(hard.pose(0).scaleX > 1);
  assert.ok(hard.pose(0).scaleY < 1);
  assert.equal(hard.pose(60).scaleX, 1);
  assert.equal(hard.pose(60).scaleY, 1);
});

test('release after a strike preserves it; clear and a fresh gesture remove stale hand state', () => {
  const hand = new HandAnimator().follow(hit, 0).strike(hit, 100).endFollow();
  assert.equal(hand.pose(100).contact, true);
  hand.follow({ ...hit, x: 99 }, 130).endFollow();
  assert.equal(hand.pose(140), null);
  hand.strike(hit, 200).clear();
  assert.equal(hand.pose(200), null);
});

test('reduced motion shows a brief stationary palm with no trail or squash', () => {
  for (const options of [{ reducedMotion: true }, { reduceMotion: true }]) {
    const hand = new HandAnimator().strike(hit, 900, options);
    for (const time of [900, 940, 1020]) {
      const pose = hand.pose(time);
      assert.equal(pose.x, hit.x);
      assert.equal(pose.y, hit.y);
      assert.equal(pose.trail, 0);
      assert.equal(pose.scaleX, 1);
      assert.equal(pose.scaleY, 1);
    }
    assert.ok(hand.pose(1020).alpha < 1);
    assert.equal(hand.pose(1060), null);
  }
  const hand = new HandAnimator().strike(hit, 0);
  assert.equal(hand.pose(60, { reduceMotion: true }).x, hit.x);
});

test('invalid input cannot produce nonfinite or unbounded poses', () => {
  for (const point of [{}, { x: NaN, y: Infinity, direction: NaN, power: NaN }, { x: -10, y: 40, direction: -999, power: 100 }]) {
    const hand = new HandAnimator().strike(point, NaN);
    for (const time of [NaN, 0, 20, 390]) {
      const pose = hand.pose(time);
      for (const value of Object.values(pose)) if (typeof value === 'number') assert.ok(Number.isFinite(value));
      assert.ok(pose.power >= 0 && pose.power <= 1);
      assert.ok(pose.alpha >= 0 && pose.alpha <= 1);
      assert.ok(pose.scale > 0);
    }
  }
});

function canvasRecorder() {
  const commands = [];
  const context = { globalAlpha: 1 };
  context.createLinearGradient = (...args) => {
    commands.push({ method: 'createLinearGradient', args });
    return { addColorStop: () => {} };
  };
  for (const method of ['save', 'restore', 'translate', 'rotate', 'scale', 'drawImage', 'beginPath', 'moveTo', 'lineTo', 'bezierCurveTo', 'quadraticCurveTo', 'closePath', 'fill', 'stroke']) {
    context[method] = (...args) => {
      for (const value of args) if (typeof value === 'number') assert.ok(Number.isFinite(value));
      commands.push({ method, args });
    };
  }
  return { context, commands };
}

test('renderer anchors the bitmap at its palm pivot, mirrors direction, and restores the context', () => {
  const { context, commands } = canvasRecorder();
  const image = { complete: true, naturalWidth: 400, naturalHeight: 600 };
  const pose = new HandAnimator().strike({ ...hit, direction: -1 }, 0).pose(0);
  drawSlappingHand(context, { image, pose, width: 200, pivot: { x: 0.5, y: 0.6 } });
  assert.deepEqual(commands.find(c => c.method === 'translate').args, [hit.x, hit.y]);
  assert.ok(commands.find(c => c.method === 'scale').args[0] < 0);
  assert.deepEqual(commands.find(c => c.method === 'drawImage').args, [image, -100, -180, 200, 300]);
  assert.equal(commands.filter(c => c.method === 'save').length, commands.filter(c => c.method === 'restore').length);
});

test('renderer draws nothing when idle; unloaded artwork uses a finite vector fallback', () => {
  const { context, commands } = canvasRecorder();
  drawSlappingHand(context, { pose: null });
  assert.equal(commands.length, 0);
  drawSlappingHand(context, { image: { complete: false }, pose: new HandAnimator().strike(hit, 0).pose(0) });
  assert.equal(commands.some(c => c.method === 'drawImage'), false);
  assert.ok(commands.some(c => c.method === 'fill'));
  assert.equal(commands.filter(c => c.method === 'save').length, commands.filter(c => c.method === 'restore').length);
});

test('the forearm continues offstage behind the bitmap and can be disabled', () => {
  const image = { complete: true, naturalWidth: 1024, naturalHeight: 1536 };
  const pose = new HandAnimator().follow(hit, 0).pose(0);
  const { context, commands } = canvasRecorder();
  drawSlappingHand(context, { image, pose, width: 170 });
  const bitmapIndex = commands.findIndex(c => c.method === 'drawImage');
  const armFillIndex = commands.findIndex(c => c.method === 'fill');
  assert.ok(armFillIndex > 0 && armFillIndex < bitmapIndex, 'the wrist sprite covers the arm join');
  assert.ok(commands.slice(0, bitmapIndex).some(c => c.method === 'lineTo' && c.args[1] > 600), 'the forearm extends past the canvas edge');
  assert.equal(commands.filter(c => c.method === 'save').length, commands.filter(c => c.method === 'restore').length);
  const disabled = canvasRecorder();
  drawSlappingHand(disabled.context, { image, pose, extendArm: false });
  assert.equal(disabled.commands.some(c => c.method === 'fill'), false);
  assert.equal(disabled.commands.filter(c => c.method === 'drawImage').length, 1);
});
