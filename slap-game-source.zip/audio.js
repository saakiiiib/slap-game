const tiers = ['soft', 'medium', 'hard'];
export class SoundPlayer {
  constructor({ muted = false, volume = 0.65 } = {}) {
    this.muted = muted; this.volume = volume; this.context = null; this.sources = [];
    this.buffers = new Map(); this.pending = null;
    this.files = Promise.all(tiers.flatMap(tier => ['impact', 'voice'].map(async kind => {
      const key = `${kind}-${tier}`;
      try {
        const response = await fetch(new URL(`./assets/audio/${key}.wav`, import.meta.url));
        if (!response.ok) throw new Error('Sound asset unavailable');
        return [key, await response.arrayBuffer()];
      } catch { return [key, null]; }
    })));
  }
  async unlock() {
    try {
      if (!this.context) {
        const Audio = window.AudioContext || window.webkitAudioContext;
        if (!Audio) return false;
        this.context = new Audio();
        this.master = this.context.createGain();
        this.master.gain.value = this.muted ? 0 : this.volume;
        const limiter = this.context.createDynamicsCompressor();
        limiter.threshold.value = -12; limiter.knee.value = 10; limiter.ratio.value = 12;
        limiter.attack.value = 0.003; limiter.release.value = 0.12;
        this.master.connect(limiter).connect(this.context.destination);
        this.pending = this.files.then(files => Promise.all(files.map(async ([key, bytes]) => {
          if (!bytes) return;
          try { this.buffers.set(key, await this.context.decodeAudioData(bytes)); } catch { /* Silent fallback. */ }
        })));
      }
      if (this.context.state === 'suspended') await this.context.resume();
      await this.pending;
      return this.context.state === 'running';
    } catch { return false; }
  }
  setPreferences(muted, volume) {
    this.muted = Boolean(muted); this.volume = Math.max(0, Math.min(1, volume));
    if (this.master) this.master.gain.setValueAtTime(this.muted ? 0 : this.volume, this.context.currentTime);
  }
  stop() {
    for (const source of this.sources) { try { source.stop(); } catch { /* Already finished. */ } }
    this.sources = [];
  }
  play(power) {
    if (this.muted || !this.context || this.context.state !== 'running') return;
    this.stop(); // A new reaction replaces the old voice instead of stacking screams.
    const tier = power < 0.34 ? 'soft' : power < 0.72 ? 'medium' : 'hard';
    for (const kind of ['impact', 'voice']) {
      const buffer = this.buffers.get(`${kind}-${tier}`);
      if (!buffer) continue;
      const source = this.context.createBufferSource(); source.buffer = buffer;
      const gain = this.context.createGain(); gain.gain.value = kind === 'voice' ? 0.48 + power * 0.32 : 0.45 + power * 0.3;
      source.playbackRate.value = kind === 'voice' ? 1.18 - power * 0.12 : 1.03;
      source.connect(gain).connect(this.master);
      source.onended = () => { source.disconnect(); gain.disconnect(); this.sources = this.sources.filter(s => s !== source); };
      source.start(this.context.currentTime + (kind === 'voice' ? 0.04 : 0));
      this.sources.push(source);
    }
  }
}
